package projeto;

public class TestaCadastro extends InterfaceCadastro {

	public static void main(String[] args) {
		menu();
	}
}